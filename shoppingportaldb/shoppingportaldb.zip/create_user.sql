
CREATE USER 'shopdb'@'%' IDENTIFIED BY 'shopdb';
