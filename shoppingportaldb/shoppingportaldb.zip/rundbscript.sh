




echo $PATH
OSNAME=`uname -s`
FILE_PATH=/tmp/applifire/db/Z8SVGEF2PERLAVEDG9BPUG/DB683082-A9D8-43A3-AA3A-B473A59AE6E9





sh $FILE_PATH/create.sh  
sh $FILE_PATH/alter.sh  
sh $FILE_PATH/loaddata.sh   
